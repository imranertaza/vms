<style type="text/css">
    .dropdown-menu > a {
        color: #777;
    }
    .dropdown-menu{
        top: 60px !important;
    }
    .btn-info {
        background-color: #00c0ef;
        border-color: #00acd6;
    }
    .table-responsive,
    .dataTables_scrollBody {
        overflow: visible !important;
    }
</style>

<!--`c_opening_balance` varchar(255) NOT NULL,-->

<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0 text-dark">List Customers
                </h1>
            </div>
            <!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?= base_url(); ?>/dashboard">Dashboard</a></li>
                    <li class="breadcrumb-item active">List Customers</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive">
<!--                    custtbl-->
                    <table class="table table-customer card-table table-vcenter text-nowrap">
                        <thead>
                        <tr>
                            <?php if (userpermission('lr_cust_edit')) { ?>
                                <th>Action</th>
                            <?php } ?>
                            <th class="w-1">S.No</th>
                            <th>Name</th>
                            <th>Mobile</th>
                            <th>Opening Balance</th>
                            <th>Total Due</th>
                            <th>Email</th>
<!--                            <th>Address</th>-->
                            <th>Status</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if (!empty($customerlist)) {
                            $count = 1;
                            foreach ($customerlist as $customerlists) {
                                ?>
                                <tr>
                                    <td>
                                        <div class="btn-group">
                                            <button class="btn btn-info btn-sm dropdown-toggle" type="button"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Actions <span class="caret"></span>
                                            </button>
                                            <div class="dropdown-menu">
                                                <a href="#" class="dropdown-item font-12-px"><i class="fa fa-money"
                                                                                                aria-hidden="true"></i>
                                                    Advance Payment
                                                </a>
                                                <a href="#" class="dropdown-item font-12-px"><i class="fa fa-shield"
                                                                                                aria-hidden="true"></i>
                                                    Security
                                                    Deposit
                                                </a>
                                                <a href="#" class="dropdown-item font-12-px"><i class="fa fa-recycle"
                                                                                                aria-hidden="true"></i>
                                                    Refund/Cheque
                                                    Return
                                                </a>
                                                <a href="#" class="dropdown-item font-12-px"><i class="fa fa-user"
                                                                                                aria-hidden="true"></i>
                                                    Contact info
                                                </a>
                                                <a href="#" class="dropdown-item font-12-px"><i class="fa fa-eye"
                                                                                                aria-hidden="true"></i>
                                                    View
                                                </a>
                                                <?php if (userpermission('lr_cust_edit')) { ?>
                                                    <a href="<?php echo base_url(); ?>customer/editcustomer/<?php echo output($customerlists['c_id']); ?>"
                                                       class="dropdown-item font-12-px"><i class="fa fa-pencil"
                                                                                           aria-hidden="true"></i>
                                                        Edit
                                                    </a>
                                                <?php } ?>
                                                <a href="<?php echo base_url(); ?>customer/ledger"class="dropdown-item font-12-px"><i class="fa fa-anchor"
                                                                                                aria-hidden="true"></i>
                                                    Ledger
                                                </a>
                                                <a href="#" class="dropdown-item font-12-px"><i
                                                            class="fa fa-arrow-circle-up" aria-hidden="true"></i>
                                                    Sales
                                                </a>
                                                <a href="#" class="dropdown-item font-12-px"><i class="fa fa-link"
                                                                                                aria-hidden="true"></i>
                                                    References
                                                </a>
                                                <a href="#" class="dropdown-item font-12-px"><i class="fa fa-paperclip"
                                                                                                aria-hidden="true"></i>
                                                    Documents &amp; Note
                                                </a>
                                                <a href="#" class="dropdown-item font-12-px"><i class="fa fa-times"
                                                                                                aria-hidden="true"></i>
                                                    Deactivate
                                                </a>
                                            </div>
                                        </div>
                                    </td>
                                    <td> <?php echo output($count);
                                        $count++; ?></td>
                                    <td> <?php echo output($customerlists['c_name']); ?></td>
                                    <td> <?php echo output($customerlists['c_mobile']); ?></td>
                                    <td> <?php echo output($customerlists['c_opening_balance']); ?></td>
                                    <td> </td>
                                    <td><?php echo output($customerlists['c_email']); ?></td>
<!--                                    <td>--><?php //echo output($customerlists['c_address']); ?><!--</td>-->
                                    <td>
                                        <span class="badge <?php echo ($customerlists['c_isactive'] == '1') ? 'badge-success' : 'badge-danger'; ?> "><?php echo ($customerlists['c_isactive'] == '1') ? 'Active' : 'Inactive'; ?></span>
                                    </td>
<!--                                    --><?php //if (userpermission('lr_cust_edit')) { ?>
<!--                                        <td>-->
<!--                                            <a class="icon"-->
<!--                                               href="--><?php //echo base_url(); ?><!--customer/editcustomer/--><?php //echo output($customerlists['c_id']); ?><!--">-->
<!--                                                <i class="fa fa-edit"></i>-->
<!--                                            </a>-->
<!--                                        </td>-->
<!--                                    --><?php //} ?>
                                </tr>
                            <?php }
                        } ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</section>



