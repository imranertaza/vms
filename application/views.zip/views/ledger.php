<style media="screen">
  .tab-icons{margin-right: 10px;}
  .dropdown{margin-top: 20px;}
  .dropdown-button{width: 100%;text-align: left;background: white;color: black;}
  .dropdown-toggle::after{float: right;margin-top: 13px;}
  .dropdown-label{display: block;}
  .dropdown-select{width: 56%;%;height: 38px;border: 1px solid lightgray;}
  #home-tab{background-color: coral;color:#FFFF}
  #profile-tab{background-color: purple;color:#FFFF}
  #contact-tab{background-color: green;color:#FFFF}
  #newcontact-tab{background-color: #368BC1;color:#FFFF}

  .nav-tabs .nav-link.active{
    color: black !important;
    background-color: #FFFF !important;
  }
</style>

<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark">View Contact1
        </h1>
        <form method="post" action="">
          <div class="col-12">
            <div class="dropdown">
              <select class="dropdown-select" name="username" id="dropMenu">
                <option value="">Please Select</option>
                <?php if($customerlist){
                  foreach($customerlist as $ind => $val){?>
                    <option value="<?=$val['c_id']?>"><?=$val['c_name']?></option>
                    <?php
                    }
                  } ?>
              </select>
            </div>
          </div>
        </form>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?= base_url(); ?>/dashboard">Dashboard</a></li>
          <li class="breadcrumb-item active">View Contact</li>
        </ol>
        <div class="mt-5"><label>Customer Name: </label><span id="usernameMain"></span></div>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<!-- Main content -->

<ul class="nav nav-tabs" id="myTab" role="tablist" style="margin-left:23px ";>
  <li class="nav-item">
    <a class="nav-link "  id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true"><i class="fas fa-book tab-icons"></i>Contact info</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" id="profile-tab"  data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="true"><i class="fas fa-bars tab-icons"></i>Ledger</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false"><i class="far fa-object-group tab-icons"></i>Security Deposit</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="newcontact-tab"  data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false"><i class="far fa-object-group tab-icons"></i>Documents and Note</a>
  </li>

</ul>
<div class="tab-content" id="myTabContent" style="margin-left: 18px;">
  <div class="tab-pane fade  " id="home" role="tabpanel" aria-labelledby="home-tab">
    <section class="content">
      <div class="container-fluid">
        <div class="card">
          <div class="card-body p-0">
            <p>Tab1.....</p>
          </div>
        <!-- /.card-body -->
        </div>
      </div>
    </section>
  </div>
  <div  class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
    <section class="content">
      <div class="container-fluid">
        <div class="card">
          <form method="post" id="fuel" class="card" action="">
                <div class="card-body">
                  <div class="row">
                    <div class="col-sm-6 col-md-3">
                            <div class="form-group">
                              <label class="form-label">Date Range</label>
                              <div id="reportrange" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc; width: 100%">
                                  <i class="fa fa-calendar"></i>&nbsp;
                                  <span></span> <i class="fa fa-caret-down"></i>
                              </div>
                              <!--
                              <label class="form-label">Date Range</label>
                              <input type="date" class="form-control" id="v_fuelcomments">
                              -->
                            </div>
                          </div>
                      
                          <div class="col-sm-6 col-md-3">
                                <label class="form-label">Transaction Type:<span class="form-required">*</span></label>
                            <div class="form-group">
                              <select id="v_id"  class="form-control selectized"  name="v_id" required="true">
                              <option value="">Select Vechicle</option>
                            
                              <option>dsfsdf</option>
                          </select>
                            </div>
                          </div>
                      

                      
                          <div class="col-sm-6 col-md-3">
                                <label class="form-label">Transaction Amount:<span class="form-required">*</span></label>
                            <div class="form-group">
                              <select id="v_id"  class="form-control selectized"  name="v_id" required="true">
                              <option value="">Select Vechicle</option>
                            
                              <option>dsfsdf</option>
                          </select>
                            </div>
                          </div>

                          <div class="col-sm-6 col-md-3">
                            <div class="form-group">
                            <label class="form-label">Search</label>
                                <input type="text" class="form-control" id="v_fuelcomments" placeholder="Search">
                            </div>
                          </div>
                </div>
          </form>
        </div>

        <!-- /.card-body -->
      </div>

    </div>
  </section>
  <section class="content">
    <div class="container-fluid">
      <div class="card">
        <div class="card-body">
          <div class="row">
            <div class="col-sm-12 col-md-12">
              <label class="col-sm-3 pull-left">Customer Name</label>
              <div class="col-sm-9" id="username"></div>
            </div>
            <div class="col-sm-12 col-md-12">
              <label class="col-sm-3 pull-left">Customer Address</label>
              <div class="col-sm-9" id="address"></div>
            </div>
            <div class="col-sm-12 col-md-12">
              <label class="col-sm-3 pull-left">Customer Tele</label>
              <div class="col-sm-9" id="tele"></div>
            </div>
          </div>
        </div>
        <!-- /.card-body -->
      </div>
    </div>
  </section>
  </div>
  <section class="content">
    <div class="container-fluid">
      <div class="card">
        <form method="post" id="fuel" class="card" action="">
          <div class="card-body">
            <div class="row">
              <div class="col-sm-6 col-md-3">
                <div class="form-group">
                  <label class="form-label">Date Range</label>
                  <input type="date" class="form-control" id="v_fuelcomments">
                </div>
              </div>
              <div class="col-sm-6 col-md-3">
                <label class="form-label">Transaction Type:<span class="form-required">*</span></label>
                <div class="form-group">
                  <select id="v_id"  class="form-control selectized"  name="v_id" required="true">
                    <option value="">Select Vechicle</option>
                    <option>dsfsdf</option>
                  </select>
                </div>
              </div>
              <div class="col-sm-6 col-md-3">
                <label class="form-label">Transaction Amount:
                  <span class="form-required">*</span>
                </label>
                <div class="form-group">
                  <select id="v_id"  class="form-control selectized"  name="v_id" required="true">
                    <option value="">Select Vechicle</option>
                    <option>dsfsdf</option>
                  </select>
                </div>
              </div>
              <div class="col-sm-6 col-md-3">
                <div class="form-group">
                  <label class="form-label">Search</label>
                  <input type="text" class="form-control" id="v_fuelcomments" placeholder="Search">
                </div>
              </div>
            </div>
          </form>
        </div>
        <!-- /.card-body -->
      </div>
    </div>
  </section>
</div>

</div>

<script>
  
  $( document ).ready(function() {
    $(".sidebar-mini").addClass("sidebar-collapse")
    $("#dropMenu").on('change',function(){
      $.ajax({
        url:"<?php echo base_url(); ?>customer/fetch_customer",
        method:"POST",
         dataType: "json",
        data:{cust_id:$(this).val()},
        success:function(data){
          $("#username,#usernameMain").html(data[0].c_name)
          $("#address").html(data[0].c_address)
          $("#tele").html(data[0].c_mobile)
          
          //console.log(data[0])
        }
      });
    });
    var start = moment().subtract(29, 'days');
    var end = moment();

    function cb(start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
    }

    $('#reportrange').daterangepicker({
        startDate: start,
        endDate: end,
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
           'This Month': [moment().startOf('month'), moment().endOf('month')],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
           'This Month Last Year': [moment().startOf('month'), moment().endOf('month')],
           'This Year': [moment().startOf('year'), moment().endOf('year')],
           'Last Year': [moment().subtract(1, 'year').startOf('year'), moment().subtract(1, 'year').endOf('year')],
           'Current financial Year': [moment().startOf('year'), moment().endOf('year')],
           'Last financial Year': [moment().subtract(1, 'year').startOf('year'), moment().subtract(1, 'year').endOf('year')],
        }
    }, cb);

    cb(start, end);  
  });
</script>



<!-- /.content -->
