-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 14, 2021 at 08:29 AM
-- Server version: 10.3.30-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vimi420_vms`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_group_id` int(11) NOT NULL,
  `child_account_type_id` int(11) NOT NULL,
  `account_type_id` int(11) DEFAULT NULL,
  `added_by` int(11) NOT NULL,
  `account_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `main_account_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `account_number`, `account_level`, `note`, `account_group_id`, `child_account_type_id`, `account_type_id`, `added_by`, `account_name`, `main_account_id`) VALUES
(1, '1', 'main_account', '', 6, 1, 1, 1, 'Cash', NULL),
(2, '123', 'main_account', '123', 6, 1, 1, 1, 'testtt', NULL),
(3, '123', 'main_account', '', 6, 1, NULL, 1, 'faheem', NULL),
(4, '123', 'main_account', '', 6, 1, NULL, 1, 'abc', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `account_groups`
--

CREATE TABLE `account_groups` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `child_account_type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `account_groups`
--

INSERT INTO `account_groups` (`id`, `name`, `note`, `child_account_type_id`) VALUES
(6, 'Cash Account Group', '', 1),
(8, 'Customer Cheques Account Group', '', 1),
(9, 'Card Account Group', '', 1),
(13, 'Direct Expense Group', '', 5),
(14, 'CGOS Account Group', '', 5),
(15, 'Sales Income Group', '', 6),
(16, 'Bank Account Group', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `account_types`
--

CREATE TABLE `account_types` (
  `id` int(11) NOT NULL,
  `name` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `account_types`
--

INSERT INTO `account_types` (`id`, `name`) VALUES
(1, 'Assets'),
(2, 'Liabilities'),
(3, 'Income'),
(4, 'Expenses'),
(5, 'Equity');

-- --------------------------------------------------------

--
-- Table structure for table `child_account_types`
--

CREATE TABLE `child_account_types` (
  `id` int(11) NOT NULL,
  `child_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `child_account_types`
--

INSERT INTO `child_account_types` (`id`, `child_name`, `parent_id`) VALUES
(1, 'Current Assets', 1),
(2, 'Fixed Assets', 1),
(3, 'Current Liabilities', 2),
(4, 'Long Term Liabilities', 2),
(5, 'Expense Account', 4),
(6, 'Income Account', 3),
(7, 'Equity Account ', 5);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `c_id` int(11) NOT NULL,
  `c_name` varchar(256) NOT NULL,
  `c_mobile` varchar(15) NOT NULL,
  `c_email` varchar(100) NOT NULL,
  `c_address` varchar(256) NOT NULL,
  `c_created_date` datetime NOT NULL,
  `c_pwd` varchar(100) DEFAULT NULL,
  `c_isactive` varchar(11) NOT NULL DEFAULT '1',
  `c_modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `c_opening_balance` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`c_id`, `c_name`, `c_mobile`, `c_email`, `c_address`, `c_created_date`, `c_pwd`, `c_isactive`, `c_modified_date`, `c_opening_balance`) VALUES
(1, 'Customer 1', '111111111', 'c1@1.com', 'aaa\r\nwertfssc\r\naasfevb\r\nxascv\r\n1234', '2021-06-24 08:01:49', NULL, '1', '2021-06-24 08:02:00', ''),
(2, 'Customer 2', '222222222', 'c2@1.com', '111', '2021-06-26 03:23:14', NULL, '1', '2021-06-26 03:23:40', '5000');

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `d_id` int(11) NOT NULL,
  `d_name` varchar(100) NOT NULL,
  `d_mobile` varchar(15) NOT NULL,
  `d_address` varchar(250) NOT NULL,
  `d_age` int(11) NOT NULL,
  `d_licenseno` varchar(100) NOT NULL,
  `d_license_expdate` date NOT NULL,
  `d_total_exp` int(11) NOT NULL,
  `d_doj` date NOT NULL,
  `d_ref` varchar(256) DEFAULT NULL,
  `d_is_active` int(11) NOT NULL DEFAULT 1,
  `d_created_by` varchar(100) NOT NULL,
  `d_created_date` datetime NOT NULL,
  `d_modified_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `drivers`
--

INSERT INTO `drivers` (`d_id`, `d_name`, `d_mobile`, `d_address`, `d_age`, `d_licenseno`, `d_license_expdate`, `d_total_exp`, `d_doj`, `d_ref`, `d_is_active`, `d_created_by`, `d_created_date`, `d_modified_date`) VALUES
(1, 'Driver 1', '111111111', '1111', 32, '1111', '2021-06-30', 12, '2021-06-20', '111', 1, '1', '2021-06-20 11:21:05', '2021-06-20 11:21:42');

-- --------------------------------------------------------

--
-- Table structure for table `email_template`
--

CREATE TABLE `email_template` (
  `et_id` int(11) NOT NULL,
  `et_name` varchar(256) NOT NULL,
  `et_subject` varchar(100) NOT NULL,
  `et_body` longtext NOT NULL,
  `et_created_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `email_template`
--

INSERT INTO `email_template` (`et_id`, `et_name`, `et_subject`, `et_body`, `et_created_date`) VALUES
(1, 'booking', 'Booking Confirmation - SYZYGY Ezy Fleet', '<p>Dear Customer,<p>\r\n\r\n<p>Thank you for choosing SYZYGY EzyFleet<p>\r\n\r\n<p>We look forward to welcoming you to strat trip.<p>\r\n\r\n<p>{{bookingdetails}}<p>\r\n\r\n<p>Our professional and friendly staff are committed to ensuring your travel is both enjoyable and comfortable.<p>\r\n\r\n<p>Should you have any requests prior to your travel, please do not hesitate to contact us and we will endeavor to assist you whenever possible.<p>', '2021-06-20 10:56:22'),
(2, 'tracking', 'Trip Tracking - YZYGY Ezy Fleet', '<p>Dear Customer,</p>\r\n\r\n<p>Please use below url to track trip live location.</p>\r\n\r\n<p>URL : {{url}}<p>', '2021-06-20 10:56:33');

-- --------------------------------------------------------

--
-- Table structure for table `fuel`
--

CREATE TABLE `fuel` (
  `v_fuel_id` int(10) NOT NULL,
  `v_id` int(100) NOT NULL,
  `v_fuel_quantity` varchar(255) CHARACTER SET latin1 NOT NULL,
  `v_odometerreading` varchar(100) DEFAULT NULL,
  `v_fuelprice` varchar(255) CHARACTER SET latin1 NOT NULL,
  `v_fuelfilldate` date NOT NULL,
  `v_fueladdedby` varchar(100) NOT NULL,
  `v_fuelcomments` varchar(256) NOT NULL,
  `v_created_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fuel`
--

INSERT INTO `fuel` (`v_fuel_id`, `v_id`, `v_fuel_quantity`, `v_odometerreading`, `v_fuelprice`, `v_fuelfilldate`, `v_fueladdedby`, `v_fuelcomments`, `v_created_date`) VALUES
(1, 1, '100', '123000', '13700', '2021-06-24', '1', '', '2021-06-24 07:10:30');

-- --------------------------------------------------------

--
-- Table structure for table `geofences`
--

CREATE TABLE `geofences` (
  `geo_id` int(11) NOT NULL,
  `geo_name` varchar(128) NOT NULL,
  `geo_description` varchar(128) DEFAULT NULL,
  `geo_area` varchar(4096) NOT NULL,
  `geo_vehicles` varchar(256) NOT NULL,
  `geo_createddate` datetime NOT NULL DEFAULT current_timestamp(),
  `geo_modifieddate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `geofence_events`
--

CREATE TABLE `geofence_events` (
  `ge_id` int(11) NOT NULL,
  `ge_v_id` varchar(11) NOT NULL,
  `ge_geo_id` varchar(11) NOT NULL,
  `ge_event` varchar(256) NOT NULL,
  `ge_timestamp` varchar(100) NOT NULL,
  `ge_created_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `incomeexpense`
--

CREATE TABLE `incomeexpense` (
  `ie_id` int(11) NOT NULL,
  `ie_v_id` varchar(100) NOT NULL,
  `ie_date` date NOT NULL,
  `ie_type` varchar(100) NOT NULL,
  `ie_description` varchar(256) NOT NULL,
  `ie_amount` int(100) NOT NULL,
  `ie_created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `ie_modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `incomeexpense`
--

INSERT INTO `incomeexpense` (`ie_id`, `ie_v_id`, `ie_date`, `ie_type`, `ie_description`, `ie_amount`, `ie_created_date`, `ie_modified_date`) VALUES
(1, '1', '2021-06-21', 'income', 'payment from trip and dfdsf', 433, '2021-06-23 06:10:18', '2021-06-23 12:40:20'),
(2, '1', '2021-06-24', 'expense', 'trip expenses', 100, '2021-06-24 03:06:31', '2021-06-24 07:06:31'),
(3, '1', '2021-06-24', 'expense', 'Added fuel - ', 13700, '2021-06-24 00:00:00', '2021-06-24 07:11:01'),
(4, '1', '2021-06-24', 'income', 'payment from trip and advance payment', 500, '2021-06-24 00:00:00', '2021-06-24 07:17:25');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `u_id` int(11) NOT NULL,
  `u_name` varchar(250) NOT NULL,
  `u_username` varchar(250) NOT NULL,
  `u_password` varchar(250) NOT NULL,
  `u_isactive` varchar(100) NOT NULL DEFAULT '1',
  `u_email` varchar(256) NOT NULL,
  `u_created_date` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`u_id`, `u_name`, `u_username`, `u_password`, `u_isactive`, `u_email`, `u_created_date`) VALUES
(1, 'syzygy', '123@gmail.com', '1ded704ce9ba546acc563f4c9ef0eb52', '1', 'syzygysec@gmail.com', '2021-06-27 11:08:16'),
(2, 'test', 'test', '098f6bcd4621d373cade4e832627b4f6', '1', 'test@yahoo.com', '2021-06-29 00:46:56'),
(3, 'tt', 'tt', 'accc9105df5383111407fd5b41255e23', '1', 'tt@yahoo.com', '2021-06-29 00:47:34'),
(4, 'twst2', 'twst2', '48589fb7fbc7abbbb2941363e3681c75', '1', 'twst2@gmail.com', '2021-06-29 00:58:08'),
(5, 'twst2', 'twst2', '48589fb7fbc7abbbb2941363e3681c75', '1', 'twst2@gmail.com', '2021-06-29 00:58:08');

-- --------------------------------------------------------

--
-- Table structure for table `login_roles`
--

CREATE TABLE `login_roles` (
  `lr_id` int(11) NOT NULL,
  `lr_u_id` int(11) NOT NULL,
  `lr_vech_list` int(11) NOT NULL DEFAULT 0,
  `lr_vech_list_view` int(11) NOT NULL DEFAULT 0,
  `lr_vech_list_edit` int(11) NOT NULL DEFAULT 0,
  `lr_vech_add` int(11) NOT NULL DEFAULT 0,
  `lr_vech_group` int(11) NOT NULL DEFAULT 0,
  `lr_vech_group_add` int(11) NOT NULL DEFAULT 0,
  `lr_vech_group_action` int(11) NOT NULL DEFAULT 0,
  `lr_drivers_list` int(11) NOT NULL DEFAULT 0,
  `lr_drivers_list_edit` int(11) NOT NULL DEFAULT 0,
  `lr_drivers_add` int(11) NOT NULL DEFAULT 0,
  `lr_trips_list` int(11) NOT NULL DEFAULT 0,
  `lr_trips_list_edit` int(11) NOT NULL DEFAULT 0,
  `lr_trips_add` int(11) NOT NULL DEFAULT 0,
  `lr_cust_list` int(11) NOT NULL DEFAULT 0,
  `lr_cust_edit` int(11) NOT NULL DEFAULT 0,
  `lr_cust_add` int(11) NOT NULL DEFAULT 0,
  `lr_fuel_list` int(11) NOT NULL DEFAULT 0,
  `lr_fuel_edit` int(11) NOT NULL DEFAULT 0,
  `lr_fuel_add` int(11) NOT NULL DEFAULT 0,
  `lr_reminder_list` int(11) NOT NULL DEFAULT 0,
  `lr_reminder_delete` int(11) NOT NULL DEFAULT 0,
  `lr_reminder_add` int(11) NOT NULL DEFAULT 0,
  `lr_ie_list` int(11) NOT NULL DEFAULT 0,
  `lr_ie_edit` int(11) NOT NULL DEFAULT 0,
  `lr_ie_add` int(11) NOT NULL DEFAULT 0,
  `lr_tracking` int(11) NOT NULL DEFAULT 0,
  `lr_liveloc` int(11) NOT NULL DEFAULT 0,
  `lr_geofence_add` int(11) NOT NULL DEFAULT 0,
  `lr_geofence_list` int(11) NOT NULL DEFAULT 0,
  `lr_geofence_delete` int(11) NOT NULL DEFAULT 0,
  `lr_geofence_events` int(11) NOT NULL DEFAULT 0,
  `lr_reports` int(11) NOT NULL DEFAULT 0,
  `lr_settings_smtp` int(11) NOT NULL DEFAULT 0,
  `lr_settings_email_temp` int(11) NOT NULL DEFAULT 0,
  `lr_super_admin_setting` int(11) NOT NULL DEFAULT 0,
  `lr_settings` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_roles`
--

INSERT INTO `login_roles` (`lr_id`, `lr_u_id`, `lr_vech_list`, `lr_vech_list_view`, `lr_vech_list_edit`, `lr_vech_add`, `lr_vech_group`, `lr_vech_group_add`, `lr_vech_group_action`, `lr_drivers_list`, `lr_drivers_list_edit`, `lr_drivers_add`, `lr_trips_list`, `lr_trips_list_edit`, `lr_trips_add`, `lr_cust_list`, `lr_cust_edit`, `lr_cust_add`, `lr_fuel_list`, `lr_fuel_edit`, `lr_fuel_add`, `lr_reminder_list`, `lr_reminder_delete`, `lr_reminder_add`, `lr_ie_list`, `lr_ie_edit`, `lr_ie_add`, `lr_tracking`, `lr_liveloc`, `lr_geofence_add`, `lr_geofence_list`, `lr_geofence_delete`, `lr_geofence_events`, `lr_reports`, `lr_settings_smtp`, `lr_settings_email_temp`, `lr_super_admin_setting`, `lr_settings`) VALUES
(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0),
(2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0),
(3, 3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `n_id` int(11) NOT NULL,
  `n_subject` varchar(256) NOT NULL,
  `n_message` varchar(256) DEFAULT NULL,
  `n_is_read` int(11) NOT NULL DEFAULT 0,
  `n_created_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `p_id` int(11) NOT NULL,
  `p_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_no_of_customers` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_price_interval` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_interval` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_trial_days` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_currency` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_isactive` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `p_created_date` datetime DEFAULT NULL,
  `p_modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`p_id`, `p_name`, `p_description`, `p_no_of_customers`, `p_price_interval`, `p_interval`, `p_trial_days`, `p_currency`, `p_price`, `p_isactive`, `p_created_date`, `p_modified_date`) VALUES
(1, 'silver', 'silver', '10', 'days', '10', '10', 'dollar', '150', '1', '2021-07-02 05:54:57', NULL),
(2, 'Gold', 'Gold', '20', 'days', '20', '5', 'dollar', '500', '1', '2021-07-02 05:55:18', NULL),
(3, 'Package 1', 'asdf Package', '12', 'days', '2', '0', 'USD', '1', '1', '2021-07-07 02:29:25', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `package_subscription`
--

CREATE TABLE `package_subscription` (
  `ps_id` int(11) NOT NULL,
  `ps_company_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ps_current_package` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ps_current_package_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ps_current_package_periods_in_days` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ps_package` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ps_package_currency` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ps_package_amount` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ps_package_period` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ps_start_date` date NOT NULL,
  `ps_end_date` date NOT NULL,
  `ps_trial_end_date` date NOT NULL,
  `ps_date` datetime DEFAULT NULL,
  `ps_transcation_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ps_status` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `ps_created_date` datetime DEFAULT NULL,
  `ps_modified_date` datetime DEFAULT NULL,
  `business_id` int(11) DEFAULT NULL,
  `paid_via` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ps_createdby` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ps_package_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `package_subscription`
--

INSERT INTO `package_subscription` (`ps_id`, `ps_company_name`, `ps_current_package`, `ps_current_package_value`, `ps_current_package_periods_in_days`, `ps_package`, `ps_package_currency`, `ps_package_amount`, `ps_package_period`, `ps_start_date`, `ps_end_date`, `ps_trial_end_date`, `ps_date`, `ps_transcation_id`, `ps_status`, `ps_created_date`, `ps_modified_date`, `business_id`, `paid_via`, `ps_createdby`, `ps_package_id`) VALUES
(1, 'Ezy Fleet', '', '', '', 'Gold', 'dollar', '500', '20', '2021-07-06', '2021-07-26', '2021-07-11', '2021-07-06 00:00:00', '', 'waiting', '2021-07-06 00:00:00', NULL, 1, 'offline', 'admin', 2),
(2, 'Ezy Fleet', '', '', '', 'Gold', 'dollar', '500', '20', '2021-07-06', '2021-07-26', '2021-07-11', '2021-07-06 00:00:00', '', 'waiting', '2021-07-06 00:00:00', NULL, 1, 'payhere', 'admin', 2),
(3, 'Ezy Fleet', '', '', '', 'Gold', 'dollar', '500', '20', '2021-07-07', '2021-07-27', '2021-07-12', '2021-07-06 00:00:00', '111', 'approved', '2021-07-06 05:37:08', NULL, NULL, NULL, 'admin', 2),
(4, 'Ezy Fleet', '', '', '', 'Gold', 'dollar', '500', '20', '2021-07-07', '2021-07-27', '2021-07-12', '2021-07-07 00:00:00', '', 'waiting', '2021-07-07 00:00:00', NULL, 1, 'offline', 'admin', 2),
(5, 'Ezy Fleet', '', '', '', 'silver', 'dollar', '150', '10', '2021-07-09', '2021-07-19', '2021-07-19', '2021-07-07 00:00:00', '', '', '2021-07-07 00:00:00', NULL, 1, 'offline', 'admin', 1),
(6, 'Ezy Fleet', '', '', '', 'Gold', 'dollar', '500', '20', '2021-07-07', '2021-07-27', '2021-07-12', '2021-07-07 00:00:00', '', 'waiting', '2021-07-07 00:00:00', NULL, 1, 'payhere', 'admin', 2),
(7, 'Ezy Fleet', '', '', '', 'Gold', 'dollar', '500', '20', '2021-07-07', '2021-07-27', '2021-07-12', '2021-07-07 00:00:00', '', 'waiting', '2021-07-07 00:00:00', NULL, 1, 'offline', 'admin', 2),
(8, 'Ezy Fleet', '', '', '', 'silver', 'dollar', '150', '10', '2021-07-04', '2021-07-14', '2021-07-14', '2021-07-07 00:00:00', '11111', 'approved', '2021-07-07 02:22:05', NULL, NULL, NULL, 'admin', 1),
(9, 'Ezy Fleet', '', '', '', 'Package 1', 'USD', '1', '2', '2021-07-06', '2021-07-08', '2021-07-06', '2021-07-07 00:00:00', 'w12', 'approved', '2021-07-07 02:37:42', NULL, NULL, NULL, 'admin', 3),
(11, 'Ezy Fleet', '', '1', '2', 'Gold', 'dollar', '500', '20', '2021-07-10', '2021-07-30', '2021-07-15', '2021-07-08 00:00:00', '111', 'approved', '2021-07-08 03:45:35', NULL, NULL, NULL, 'admin', 2),
(12, 'Ezy Fleet', 'Gold', '500', '20', 'Package 1', 'USD', '1', '2', '0000-00-00', '0000-00-00', '0000-00-00', '2021-07-08 00:00:00', '222', 'approved', '2021-07-08 03:45:50', NULL, NULL, NULL, 'admin', 3),
(13, 'Ezy Fleet', 'Package 1', '1', '2', 'silver', 'dollar', '150', '10', '2021-07-21', '2021-07-31', '2021-07-31', '2021-07-08 00:00:00', '22', 'approved', '2021-07-08 03:46:34', NULL, NULL, NULL, 'admin', 1),
(14, 'Ezy Fleet', '', '', '', 'Package 1', 'USD', '1', '2', '2021-07-08', '2021-07-10', '2021-07-08', '2021-07-08 00:00:00', '', 'waiting', '2021-07-08 00:00:00', NULL, 1, 'offline', 'admin', 3),
(15, 'Ezy Fleet', '', '', '', 'Gold', 'dollar', '500', '20', '2021-07-08', '2021-07-28', '2021-07-13', '2021-07-08 00:00:00', '', 'waiting', '2021-07-08 00:00:00', NULL, 1, 'payhere', 'admin', 2),
(16, 'Ezy Fleet', '', '', '', 'Package 1', 'USD', '1', '2', '2021-07-08', '2021-07-10', '2021-07-08', '2021-07-08 00:00:00', '', 'waiting', '2021-07-08 00:00:00', NULL, 1, 'payhere', 'admin', 3),
(17, 'Ezy Fleet', 'Package 1', '1', '2', 'silver', 'dollar', '150', '10', '2021-07-08', '2021-07-18', '2021-07-18', '2021-07-08 00:00:00', '', 'waiting', '2021-07-08 00:00:00', NULL, 1, 'offline', 'admin', 1),
(18, 'Ezy Fleet', 'silver', '150', '10', 'Package 1', 'USD', '1', '2', '2021-07-08', '2021-07-10', '2021-07-08', '2021-07-08 00:00:00', '', 'waiting', '2021-07-08 00:00:00', NULL, 1, 'offline', 'admin', 3),
(19, 'Ezy Fleet', 'Package 1', '1', '2', 'Package 1', 'USD', '1', '2', '2021-07-10', '2021-07-12', '2021-07-10', '2021-07-10 00:09:00', '1', 'approved', '2021-07-08 07:10:02', NULL, NULL, NULL, 'admin', 3);

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

CREATE TABLE `positions` (
  `id` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp(),
  `v_id` int(11) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `altitude` double DEFAULT NULL,
  `speed` double DEFAULT NULL,
  `bearing` double DEFAULT NULL,
  `accuracy` int(11) DEFAULT NULL,
  `provider` varchar(100) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `reminder`
--

CREATE TABLE `reminder` (
  `r_id` int(11) NOT NULL,
  `r_v_id` varchar(11) NOT NULL,
  `r_date` date NOT NULL,
  `r_message` varchar(256) NOT NULL,
  `r_isread` varchar(11) NOT NULL DEFAULT '0',
  `r_created_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reminder`
--

INSERT INTO `reminder` (`r_id`, `r_v_id`, `r_date`, `r_message`, `r_isread`, `r_created_date`) VALUES
(2, '2', '2021-06-23', 'this is test', '0', '2021-06-23 07:23:08');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `s_id` int(11) NOT NULL,
  `s_companyname` varchar(100) DEFAULT NULL,
  `s_address` varchar(100) DEFAULT NULL,
  `s_inovice_prefix` varchar(100) NOT NULL,
  `s_bg_img` varchar(100) NOT NULL,
  `s_logo` varchar(100) NOT NULL,
  `s_price_prefix` varchar(100) NOT NULL,
  `s_inovice_termsandcondition` varchar(256) NOT NULL,
  `s_inovice_servicename` varchar(100) NOT NULL,
  `s_googel_api_key` varchar(256) NOT NULL,
  `s_no_of_veh_allowed` varchar(256) NOT NULL,
  `s_help_desk_url` varchar(256) NOT NULL,
  `s_bank_name` varchar(256) NOT NULL,
  `s_branch_name` varchar(256) NOT NULL,
  `s_account_no` varchar(256) NOT NULL,
  `s_account_name` varchar(256) NOT NULL,
  `s_swift_code` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`s_id`, `s_companyname`, `s_address`, `s_inovice_prefix`, `s_bg_img`, `s_logo`, `s_price_prefix`, `s_inovice_termsandcondition`, `s_inovice_servicename`, `s_googel_api_key`, `s_no_of_veh_allowed`, `s_help_desk_url`, `s_bank_name`, `s_branch_name`, `s_account_no`, `s_account_name`, `s_swift_code`) VALUES
(1, 'Ezy Fleet', 'Malabe', 'IN', '1625083984-2.jpg', '1625109582-Untitled-4.png', 'Rs.', 'Sample invoice terms and condition..Please change it in settings page............                                                                                                                                                                               ', 'Ezy Fleet', 'AIzaSyA1tT5eHsRh7kbZDzebF-lfVzVgSX8zpLg', '12', 'https://www.google.com', 'ABC Bank', 'B Branch', '1234', 'Hi Account', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `settings_smtp`
--

CREATE TABLE `settings_smtp` (
  `smtp_host` varchar(100) NOT NULL,
  `smtp_auth` varchar(100) NOT NULL,
  `smtp_uname` varchar(100) NOT NULL,
  `smtp_pwd` varchar(100) NOT NULL,
  `smtp_issecure` varchar(100) NOT NULL,
  `smtp_port` varchar(100) NOT NULL,
  `smtp_emailfrom` varchar(100) NOT NULL,
  `smtp_replyto` varchar(100) NOT NULL,
  `smtp_createddate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `trips`
--

CREATE TABLE `trips` (
  `t_id` int(11) NOT NULL,
  `t_customer_id` varchar(11) NOT NULL,
  `t_vechicle` varchar(100) NOT NULL,
  `t_type` varchar(100) NOT NULL,
  `t_driver` varchar(100) NOT NULL,
  `t_start_date` date NOT NULL,
  `t_end_date` date NOT NULL,
  `t_trip_fromlocation` varchar(100) NOT NULL,
  `t_trip_tolocation` varchar(100) NOT NULL,
  `t_trip_fromlat` varchar(100) DEFAULT NULL,
  `t_trip_fromlog` varchar(100) DEFAULT NULL,
  `t_trip_tolat` varchar(100) DEFAULT NULL,
  `t_trip_tolog` varchar(100) NOT NULL,
  `t_totaldistance` varchar(100) NOT NULL,
  `t_trip_amount` varchar(100) NOT NULL DEFAULT '0',
  `t_trip_status` varchar(50) NOT NULL DEFAULT 'OnGoing',
  `t_trackingcode` varchar(100) DEFAULT NULL,
  `t_created_by` varchar(100) NOT NULL,
  `t_created_date` datetime NOT NULL,
  `t_modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trips`
--

INSERT INTO `trips` (`t_id`, `t_customer_id`, `t_vechicle`, `t_type`, `t_driver`, `t_start_date`, `t_end_date`, `t_trip_fromlocation`, `t_trip_tolocation`, `t_trip_fromlat`, `t_trip_fromlog`, `t_trip_tolat`, `t_trip_tolog`, `t_totaldistance`, `t_trip_amount`, `t_trip_status`, `t_trackingcode`, `t_created_by`, `t_created_date`, `t_modified_date`) VALUES
(1, '1', '1', 'singletrip', '1', '2021-06-09', '2021-06-25', '', '', '1', '1', '1', '1', '', '434', 'yettostart', '60d0776d0c90b', '1', '2021-06-21 11:26:11', '2021-06-21 11:26:37'),
(2, '1', '1', 'singletrip', '1', '2021-06-24', '2021-06-24', 'malabe', 'matale', '1', '1', '1', '1', '', '2000', 'ongoing', '60d42eabeb0c2', '1', '2021-06-24 07:07:13', '2021-06-24 07:07:33');

-- --------------------------------------------------------

--
-- Table structure for table `trip_payments`
--

CREATE TABLE `trip_payments` (
  `tp_id` int(11) NOT NULL,
  `tp_trip_id` int(11) NOT NULL,
  `tp_v_id` int(11) NOT NULL,
  `tp_amount` int(100) NOT NULL,
  `tp_notes` varchar(256) DEFAULT NULL,
  `tp_created_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trip_payments`
--

INSERT INTO `trip_payments` (`tp_id`, `tp_trip_id`, `tp_v_id`, `tp_amount`, `tp_notes`, `tp_created_date`) VALUES
(1, 1, 1, 433, 'dfdsf', '2021-06-21 07:27:10'),
(2, 2, 1, 500, 'advance payment', '2021-06-24 03:17:25');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `v_id` int(10) NOT NULL,
  `v_registration_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `v_name` varchar(100) NOT NULL,
  `v_model` varchar(255) CHARACTER SET latin1 NOT NULL,
  `v_chassis_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `v_engine_no` varchar(255) CHARACTER SET latin1 NOT NULL,
  `v_manufactured_by` varchar(255) CHARACTER SET latin1 NOT NULL,
  `v_type` varchar(100) NOT NULL,
  `v_color` varchar(100) NOT NULL,
  `v_mileageperlitre` varchar(100) NOT NULL,
  `v_is_active` int(10) NOT NULL DEFAULT 1,
  `v_group` int(11) NOT NULL,
  `v_reg_exp_date` varchar(100) NOT NULL,
  `v_api_url` varchar(100) NOT NULL,
  `v_api_username` varchar(100) NOT NULL,
  `v_api_password` varchar(100) NOT NULL,
  `v_created_by` varchar(100) NOT NULL,
  `v_created_date` datetime NOT NULL,
  `v_modified_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `v_battery_detail` varchar(100) NOT NULL,
  `v_expense_account` varchar(100) NOT NULL,
  `v_income_account` varchar(100) NOT NULL,
  `v_no_of_tyres` varchar(100) NOT NULL,
  `v_tyre_sizes` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`v_id`, `v_registration_no`, `v_name`, `v_model`, `v_chassis_no`, `v_engine_no`, `v_manufactured_by`, `v_type`, `v_color`, `v_mileageperlitre`, `v_is_active`, `v_group`, `v_reg_exp_date`, `v_api_url`, `v_api_username`, `v_api_password`, `v_created_by`, `v_created_date`, `v_modified_date`, `v_battery_detail`, `v_expense_account`, `v_income_account`, `v_no_of_tyres`, `v_tyre_sizes`) VALUES
(1, 'Vehicle 1', '1', '1', '1', '1', '1', 'CAR', '#F399EB', '0', 1, 1, '2022-01-31', 'https://vimi2.xyz/vms/api', 'Vehicle 1', '568371', '1', '2021-06-20 11:19:50', '2021-06-20 11:20:22', '', '', '', '', ''),
(2, 'To ye ri8 7 t6', 'Bike', '656', '46546u', '64478', 'Honda', 'CAR', '#905A8B', '0', 1, 1, '2021-06-10', 'https://vimi2.xyz/vms/api', 'To ye ri8 7 t6', '795134', '1', '2021-06-21 10:28:18', '2021-06-21 10:29:02', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_group`
--

CREATE TABLE `vehicle_group` (
  `gr_id` int(11) NOT NULL,
  `gr_name` varchar(256) NOT NULL,
  `gr_desc` varchar(256) NOT NULL,
  `gr_created_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicle_group`
--

INSERT INTO `vehicle_group` (`gr_id`, `gr_name`, `gr_desc`, `gr_created_date`) VALUES
(1, 'Vehicle Group 1', 'Test Vehicle group', '2021-06-20 11:17:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `account_groups`
--
ALTER TABLE `account_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `account_types`
--
ALTER TABLE `account_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `child_account_types`
--
ALTER TABLE `child_account_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `email_template`
--
ALTER TABLE `email_template`
  ADD PRIMARY KEY (`et_id`);

--
-- Indexes for table `fuel`
--
ALTER TABLE `fuel`
  ADD PRIMARY KEY (`v_fuel_id`);

--
-- Indexes for table `geofences`
--
ALTER TABLE `geofences`
  ADD PRIMARY KEY (`geo_id`);

--
-- Indexes for table `geofence_events`
--
ALTER TABLE `geofence_events`
  ADD PRIMARY KEY (`ge_id`);

--
-- Indexes for table `incomeexpense`
--
ALTER TABLE `incomeexpense`
  ADD PRIMARY KEY (`ie_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `login_roles`
--
ALTER TABLE `login_roles`
  ADD PRIMARY KEY (`lr_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`n_id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `package_subscription`
--
ALTER TABLE `package_subscription`
  ADD PRIMARY KEY (`ps_id`);

--
-- Indexes for table `positions`
--
ALTER TABLE `positions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index_user_id` (`v_id`);

--
-- Indexes for table `reminder`
--
ALTER TABLE `reminder`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `trips`
--
ALTER TABLE `trips`
  ADD PRIMARY KEY (`t_id`);

--
-- Indexes for table `trip_payments`
--
ALTER TABLE `trip_payments`
  ADD PRIMARY KEY (`tp_id`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`v_id`);

--
-- Indexes for table `vehicle_group`
--
ALTER TABLE `vehicle_group`
  ADD PRIMARY KEY (`gr_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `account_groups`
--
ALTER TABLE `account_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `account_types`
--
ALTER TABLE `account_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `child_account_types`
--
ALTER TABLE `child_account_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `email_template`
--
ALTER TABLE `email_template`
  MODIFY `et_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `fuel`
--
ALTER TABLE `fuel`
  MODIFY `v_fuel_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `geofences`
--
ALTER TABLE `geofences`
  MODIFY `geo_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `geofence_events`
--
ALTER TABLE `geofence_events`
  MODIFY `ge_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `incomeexpense`
--
ALTER TABLE `incomeexpense`
  MODIFY `ie_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `login_roles`
--
ALTER TABLE `login_roles`
  MODIFY `lr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `n_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `package_subscription`
--
ALTER TABLE `package_subscription`
  MODIFY `ps_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `positions`
--
ALTER TABLE `positions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reminder`
--
ALTER TABLE `reminder`
  MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `trips`
--
ALTER TABLE `trips`
  MODIFY `t_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `trip_payments`
--
ALTER TABLE `trip_payments`
  MODIFY `tp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `v_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vehicle_group`
--
ALTER TABLE `vehicle_group`
  MODIFY `gr_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
